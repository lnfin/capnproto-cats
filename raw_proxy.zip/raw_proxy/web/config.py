from typing import List, Optional, Union

VERBOSE = False

PROXY_REMOTE_ADDR = 'ya.ru'
PROXY_REMOTE_PORT = 80

# https?
PROXY_BIND_HTTPS = False
PROXY_REMOTE_HTTPS = False
PROXY_REMOTE_HTTPS_CHECK = False

FLAG_REGEXP = b'[A-Z0-9]{31}(=|%[Dd])'

ALLOWED_USER_AGENT_REGEXP = ''

# upper case
METHODS_WHITELIST = []
METHODS_BLACKLIST = []

HEADERS_REQUIRED = []
HEADERS_PROHIBITED = []

# case insensitive
REQ_BAD_WORDS_IN_URL: List[str] = []
REQ_BAD_WORDS_IN_BODY: List[Union[str, bytes]] = []
REQ_BAD_WORDS_IN_HEADERS: List[str] = []

RESP_BAD_WORDS_IN_BODY: List[Union[str, bytes]] = []
RESP_BAD_WORDS_IN_HEADERS: List[str] = []
RESP_MAX_ALLOWED_FLAGS = 20


def process_request_custom(method: str, url: str, headers: 'CIMultiDict', body: Optional[bytes]) -> bool:
    return True


def process_response_custom(
    method: str, url: str, headers: 'CIMultiDict', body: Optional[bytes],
    rstatus: int, rheaders: 'CIMultiDict', rbody: bytes,
) -> bool:
    return True
