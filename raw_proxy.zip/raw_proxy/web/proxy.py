import asyncio
import logging
import re
import sys
import time
import traceback
from importlib import reload
from typing import Optional
from urllib.parse import urljoin

import aiohttp
from aiohttp import web
from multidict import CIMultiDict

import config

logger = logging.getLogger("proxy")
last_reload = 0


async def proxy(request):
    # reload config each 5 seconds
    global last_reload
    if time.time() - last_reload > 5:
        last_reload = time.time()
        try:
            reload(config)  # noqa
            if config.VERBOSE:
                logger.setLevel(logging.INFO)
            else:
                logger.setLevel(logging.WARNING)
        except Exception:
            traceback.print_exception(*sys.exc_info())

    proto = 'https' if config.PROXY_REMOTE_HTTPS else 'http'
    remote_url = f'{proto}://{config.PROXY_REMOTE_ADDR}:{config.PROXY_REMOTE_PORT}'
    url = urljoin(remote_url, request.path_qs)
    method = request.method
    headers = CIMultiDict(request.headers)

    body = None
    if request.can_read_body:
        body = await request.read()

    method, url, headers, body, drop = process_request(method, url, headers, body)
    if drop:
        return web.Response(text='[filtered]', headers={'Server': 'nginx'})

    # do not compress upstream request
    if 'accept-encoding' in headers:
        del headers['accept-encoding']

    logger.info(f'\n\n=== Request upstream: {url}\n-- headers:')
    for k, v in headers.items():
        logger.info(f'{k}: {v}')

    request_params = dict(
        url=url,
        method=method,
        headers=headers,
        data=body,
        allow_redirects=False,
        skip_auto_headers=('user-agent', 'host', 'content-type', 'accept', 'accept-encoding'),
    )
    if config.PROXY_REMOTE_HTTPS and not config.PROXY_REMOTE_HTTPS_CHECK:
        connector = aiohttp.TCPConnector(ssl=False)
        async with aiohttp.request(connector=connector, **request_params) as res:
            rbody = await res.read()
        if connector:
            await connector.close()
    else:
        session = aiohttp.ClientSession()
        async with session.request(**request_params) as res:
            rbody = await res.read()
        if session:
            await session.close()

    logger.info(f'=== Response upstream: {url} {res.status}\n-- headers:')
    for k, v in res.headers.items():
        logger.info(f'{k}: {v}')

    rheaders = CIMultiDict(res.headers)
    # aiohttp return uncompressed response
    # so removing compress mark and compressed length
    for h in ['content-encoding', 'content-length']:
        if h in rheaders:
            del rheaders[h]

    rstatus = res.status

    rstatus, rheaders, rbody = process_response(method, url, headers, body, rstatus, rheaders, rbody)
    
    logger.info(f'=== Response: {rstatus}\n-- headers:')
    for k, v in rheaders.items():
        logger.info(f'{k}: {v}')
    logger.info('\n\n' + '=' * 40)

    return web.Response(body=rbody, status=rstatus, headers=rheaders)


def process_request(method: str, url: str, headers: CIMultiDict, body: Optional[bytes]):
    drop = False
    try:
        if config.METHODS_WHITELIST and method.upper() not in config.METHODS_WHITELIST:
            drop = True

        if config.METHODS_BLACKLIST and method.upper() in config.METHODS_BLACKLIST:
            drop = True
            
        if not drop and config.HEADERS_REQUIRED:
            for header in config.HEADERS_REQUIRED:
                if header not in headers:
                    drop = True
                    break
                    
        if not drop and config.HEADERS_PROHIBITED:
            for header in config.HEADERS_PROHIBITED:
                if header in headers:
                    drop = True
                    break

        if not drop and config.REQ_BAD_WORDS_IN_URL:
            url_lower = url.lower()
            for word in config.REQ_BAD_WORDS_IN_URL:
                if word.lower() in url_lower:
                    drop = True
                    break

        if not drop and config.REQ_BAD_WORDS_IN_HEADERS:
            for word in config.REQ_BAD_WORDS_IN_HEADERS:
                if word in str(headers):
                    drop = True
                    break

        if not drop and config.ALLOWED_USER_AGENT_REGEXP:
            user_agent = headers.get('User-Agent')
            if not re.match(config.ALLOWED_USER_AGENT_REGEXP, user_agent):
                drop = True

        if not drop and config.REQ_BAD_WORDS_IN_BODY:
            for word in config.REQ_BAD_WORDS_IN_BODY:
                if isinstance(word, str):
                    word = word.encode()
                if body and word in body:
                    drop = True
                    break

        if not drop and not config.process_request_custom(method=method, url=url, headers=headers, body=body):
            drop = True

    except Exception:
        traceback.print_exception(*sys.exc_info())
    return method, url, headers, body, drop


def process_response(
    method: str, 
    url: str, 
    headers: CIMultiDict,
    body: Optional[bytes], 
    rstatus: int, 
    rheaders: CIMultiDict,
    rbody: bytes,
):
    try:
        for word in config.RESP_BAD_WORDS_IN_BODY:
            if isinstance(word, str):
                word = word.encode()
            if rbody and word in rbody:
                rbody = '[filtered]'
                break

        for word in config.RESP_BAD_WORDS_IN_HEADERS:
            if word in str(rheaders):
                rbody = '[filtered]'
                break

        if config.RESP_MAX_ALLOWED_FLAGS > 0:
            flags = len(re.findall(config.FLAG_REGEXP, rbody))
            if flags > config.RESP_MAX_ALLOWED_FLAGS:
                rbody = '[filtered]'

        if not config.process_response_custom(
            method=method, url=url, headers=headers, body=body, rstatus=rstatus, rheaders=rheaders, rbody=rbody,
        ):
            rbody = '[filtered]'

        # modified response after sending request
        # if 'httpie' in headers.get('user-agent').lower():
        #     rstatus = 504
        #     rbody = '.!..'

        # if 'marker_search.py' in rbody.decode():
        #     rbody = b'N'

    except Exception:
        traceback.print_exception(*sys.exc_info())
    return rstatus, rheaders, rbody


if __name__ == "__main__":
    bind_address = '0.0.0.0'
    bind_port = 9000

    bind_https = config.PROXY_BIND_HTTPS
    https_key_path = './ssl.key'
    https_crt_path = './ssl.crt'

    logging.root.setLevel(logging.INFO)
    logging.root.addHandler(logging.StreamHandler())

    app = web.Application()
    app.router.add_route('*', '/{path:.*}', proxy)

    ssl_context = None
    if bind_https:
        import ssl
        ssl_context = ssl.SSLContext(ssl.PROTOCOL_SSLv23)
        ssl_context.load_cert_chain(https_crt_path, https_key_path)

    loop = asyncio.get_event_loop()
    f = loop.create_server(app.make_handler(), bind_address, bind_port, ssl=ssl_context)
    srv = loop.run_until_complete(f)
    print('serving on', srv.sockets[0].getsockname())
    try:
        loop.run_forever()
    except KeyboardInterrupt:
        pass


# usage
# apt install python3-virtualenv virtualenv
# virtualenv -p python3 venv
# source venv/bin/activate
# pip3 install aiohttp
# python3 proxy.py
